module EmailApplication_GL {
}